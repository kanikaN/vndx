<?php
/**
 * Contains EWSType_ItemChangeDescriptionType.
 */

/**
 * Base class for changes to individual item properties.
 *
 * @package php-ews\Types
 */
abstract class EWSType_ItemChangeDescriptionType extends EWSType_ChangeDescriptionType
{

}
