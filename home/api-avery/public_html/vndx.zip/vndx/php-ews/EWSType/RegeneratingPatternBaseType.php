<?php
/**
 * Contains EWSType_RegeneratingPatternBaseType.
 */

/**
 * Base class for regenerating patterns.
 *
 * @package php-ews\Types
 */
abstract class EWSType_RegeneratingPatternBaseType extends EWSType_IntervalRecurrencePatternBaseType
{

}
