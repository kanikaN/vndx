<?php
/**
 * Contains EWSType_FolderChangeDescriptionType.
 */

/**
 * Base class for changes to individual folder properties.
 *
 * @package php-ews\Types
 */
abstract class EWSType_FolderChangeDescriptionType extends EWSType_ChangeDescriptionType
{

}
