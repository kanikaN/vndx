<?php
/**
 * Contains EWSType_RecurrencePatternBaseType.
 */

/**
 * Base class for recurrence patterns.
 *
 * @package php-ews\Types
 */
abstract class EWSType_RecurrencePatternBaseType extends EWSType
{

}
