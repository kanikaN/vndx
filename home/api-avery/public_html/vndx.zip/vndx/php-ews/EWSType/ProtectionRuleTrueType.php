<?php
/**
 * Contains EWSType_ProtectionRuleTrueType.
 */

/**
 * Specifies a condition that always matches.
 *
 * This element must be empty.
 *
 * @package php-ews\Types
 */
class EWSType_ProtectionRuleTrueType extends EWSType
{

}
